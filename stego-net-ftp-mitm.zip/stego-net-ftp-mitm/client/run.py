import ftplib

HOST = "172.25.0.5"
USER = "username"
PASS = "123"
STR = "00111000"


ftp = ftplib.FTP()
ftp.connect(HOST)
ftp.login(USER, PASS)

for i in range(0, len(STR), 2):

    char = STR[i:i+2]
    
    if char == "00":
        print(f"Sending NOOP once for character {char}")
        ftp.sendcmd("NOOP")
        ftp.dir()  

    elif char == "01":
        print(f"Sending NOOP twice for character {char}")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.dir()  

    elif char == "10":
        print(f"Sending NOOP three times for character {char}")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.dir()  

    else:
        print(f"Sending NOOP four times for character {char}")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.dir()  

ftp.quit()
print("All commands sent")

