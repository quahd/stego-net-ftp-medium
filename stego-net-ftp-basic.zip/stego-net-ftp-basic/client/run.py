import ftplib

HOST = "172.25.0.5"
USER = "username"
PASS = "123"
STR = "00111000"

# Kết nối tới FTP server
ftp = ftplib.FTP()
ftp.connect(HOST)
ftp.login(USER, PASS)

# Duyệt qua từng ký tự trong chuỗi STR
for char in STR:
    if char == "0":
        print(f"Sending NOOP once for character {char}")
        ftp.sendcmd("NOOP")
        ftp.dir()  # Lệnh `dir` để lấy danh sách thư mục, có thể thay đổi theo yêu cầu

    elif char == "1":
        print(f"Sending NOOP twice for character {char}")
        ftp.sendcmd("NOOP")
        ftp.sendcmd("NOOP")
        ftp.dir()  # Lệnh `dir` để lấy danh sách thư mục, có thể thay đổi theo yêu cầu

# Đóng kết nối FTP
ftp.quit()
print("All commands sent")

