#!/bin/bash

HOST="172.25.0.5"
USER="username"
PASS="123"
STR="00111000"

# Kết nối FTP và gửi lệnh tương ứng với mỗi ký tự trong chuỗi
ftp -n $HOST <<EOF
user $USER $PASS
EOF

# Duyệt qua từng ký tự trong chuỗi
for ((i=0; i<${#STR}; i++)); do
    # Lấy ký tự tại vị trí i
    CHAR="${STR:$i:1}"
    
    # Nếu ký tự là '0'
    if [ "$CHAR" == "0" ]; then
        echo "Sending NOOP once for character $CHAR"
        ftp -n $HOST <<EOF
        user $USER $PASS
        quote noop
        dir
EOF
    # Nếu ký tự là '1'
    elif [ "$CHAR" == "1" ]; then
        echo "Sending NOOP twice for character $CHAR"
        ftp -n $HOST <<EOF
        user $USER $PASS
        quote noop
        quote noop
        dir
EOF
    fi
done

# Đóng kết nối FTP sau khi gửi tất cả các lệnh
echo "All commands sent"

